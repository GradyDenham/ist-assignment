Website i made for an assignment.
